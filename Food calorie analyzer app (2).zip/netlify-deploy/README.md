# SnapMyCal — Netlify deployment with real AI analysis

This folder is ready to deploy to Netlify as-is.

## What's inside
- `index.html` — the app (drop your exported HTML here, renamed to index.html)
- `netlify.toml` — tells Netlify where the serverless function lives
- `netlify/functions/analyze-meal.js` — calls Google Gemini's free-tier vision API
  to turn a food photo into calories/macros/nutrients JSON. Your API key stays
  server-side here — never exposed to the browser.

## Setup (5 minutes)
1. **Get a free Gemini API key**: https://aistudio.google.com/app/apikey (no credit card needed).
2. **Replace `index.html`** in this folder with your exported SnapMyCal HTML file
   (rename it to exactly `index.html`).
3. **Deploy this whole folder** to Netlify:
   - Drag-and-drop the folder onto https://app.netlify.com/drop, or
   - Push it to a GitHub repo and connect it as a Netlify site.
4. In the Netlify dashboard: **Site settings → Environment variables** →
   add `GEMINI_API_KEY` = your key from step 1.
5. **Redeploy** (Netlify → Deploys → Trigger deploy) so the function picks up the key.
6. Open your live `.netlify.app` URL on your phone in Safari/Chrome — tap the
   camera button, take a real photo, and it'll call Gemini for a real
   calorie/nutrient breakdown. If the function errors (key missing, offline,
   rate-limited), the app quietly falls back to a demo estimate so it never
   looks broken — you'll see a small "Demo estimate" badge on the results screen
   when that happens.

## Notes
- Gemini's free tier (Flash model) covers this comfortably for personal use —
  no billing required, but rate limits apply (see Google AI Studio dashboard).
- Barcode scanning is still a visual mock — a real barcode/UPC lookup would need
  a separate food database API (e.g. Open Food Facts), not covered here.
